package com.example.finalproject;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.ThemeUtils;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    public final static String EXTRA_MESSAGE="MESSAGE";
    private ListView objListView;
    DBHelper db;
    private SearchView searchView;
    Button button;
    RelativeLayout rV;
    TextView tV;
    TextView tV2;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DBHelper(this);
        ArrayList<String> arrayList = db.getAllClients();
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        searchView = findViewById(R.id.searchViewID);

        objListView = (ListView) findViewById(R.id.listView1);
        objListView.setAdapter(arrayAdapter);
        objListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int id_to_search = position + 1;
                Bundle dataBundle = new Bundle();
                Toast.makeText(MainActivity.this, id_to_search + " " + position, Toast.LENGTH_SHORT).show();
                dataBundle.putInt("id", id_to_search);
                Intent intent = new Intent(getApplicationContext(), DisplayClient.class);
                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });
        tV = findViewById(R.id.textView);
        tV2 = findViewById(R.id.textView6);

        rV = findViewById(R.id.relativeLayout);
        button = findViewById(R.id.button);

        button.setOnTouchListener(new View.OnTouchListener() {
            final GestureDetector gestureDetector = new GestureDetector(getApplicationContext(), new GestureDetector.SimpleOnGestureListener(){
                @Override
                public void onLongPress(MotionEvent e) {
                    rV.setBackgroundColor(getResources().getColor(R.color.purple_500));
                    tV.setTextColor(Color.WHITE);
                    tV2.setTextColor(Color.WHITE);
                    objListView.setBackgroundColor(Color.WHITE);
                    super.onLongPress(e);
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    rV.setBackgroundColor(Color.BLACK);
                    tV.setTextColor(Color.GREEN);
                    tV2.setTextColor(Color.GREEN);
                    objListView.setBackgroundColor(Color.WHITE);
                    return super.onDoubleTap(e);
                }

                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    rV.setBackgroundColor(Color.WHITE);
                    tV.setTextColor(Color.GRAY);
                    tV2.setTextColor(Color.GRAY);
                    objListView.setBackgroundColor(Color.WHITE);
                    return super.onSingleTapConfirmed(e);
                }
            });

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                gestureDetector.onTouchEvent(motionEvent);
                return false;
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch(item.getItemId())
        {
            case R.id.item1:Bundle dataBundle = new Bundle();
             //   Toast.makeText(MainActivity.this, value + " " + position, Toast.LENGTH_SHORT).show();

                dataBundle.putInt("id", 0);

                Intent intent = new Intent(getApplicationContext(), DisplayClient.class);
                intent.putExtras(dataBundle);

                startActivityForResult(intent, 0);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        db=new DBHelper(this);
        ArrayList<String> arrayList=db.getAllClients();
        ArrayAdapter arrayAdapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList);

        objListView=(ListView)findViewById(R.id.listView1);
        objListView.setAdapter(arrayAdapter);
    }


    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        AlertDialog.Builder alBuilder;
        alBuilder = new AlertDialog.Builder(MainActivity.this);
        //alBuilder.setIcon(R.drawable.question_icon1);
        alBuilder.setTitle("Alert");
        alBuilder.setMessage("Are you sure to exit?");
        alBuilder.setCancelable(false);
    }
}

